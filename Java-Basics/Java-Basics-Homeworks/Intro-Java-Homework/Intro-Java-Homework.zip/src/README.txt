http://www.apache.org/dyn/closer.cgi/pdfbox/1.8.6/pdfbox-app-1.8.6.jar

This is the link for the external library that works with PDF