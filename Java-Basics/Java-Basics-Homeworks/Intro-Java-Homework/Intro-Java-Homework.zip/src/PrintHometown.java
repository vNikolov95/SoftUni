
public class PrintHometown {
	public static void main(String[] args) {
		System.out.println("My hometown is Kazanlak");
	}
}
